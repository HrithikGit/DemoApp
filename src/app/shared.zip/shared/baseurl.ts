// selecting ip adress not working so downloaded ngrok to create url
//export const baseURL = "http://localhost:3000/";
//export const baseURL = "https://my-json-server.typicode.com/HrithikGit/Server/";
export const baseURL = "https://my-json-server.typicode.com/swetavooda/server/";