export interface Button {    
    name: string;    
    id: number;
    type: string;
    description: string;
    list: string[];
}